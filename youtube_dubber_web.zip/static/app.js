async function postJson(url, data){
  const r = await fetch(url, {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(data)});
  return r.json();
}
document.getElementById('dub').addEventListener('click', async ()=>{
  const url = document.getElementById('url').value.trim();
  if(!url) return alert('Paste a YouTube URL');
  document.getElementById('status').innerText = 'Submitting...';
  const res = await postJson('/api/dub', {url});
  if(res.error){ document.getElementById('status').innerText = 'Error: '+res.error; return; }
  const jobId = res.job_id;
  document.getElementById('status').innerText = `Job queued: ${jobId}`;
  const poll = setInterval(async ()=>{
    const s = await (await fetch('/api/status/'+jobId)).json();
    document.getElementById('status').innerText = 'Status: ' + s.status;
    if(s.status === 'done'){
      clearInterval(poll);
      document.getElementById('status').innerHTML = `Done — <a href="${s.download}">Download dubbed video</a>`;
    }
  }, 3000);
});